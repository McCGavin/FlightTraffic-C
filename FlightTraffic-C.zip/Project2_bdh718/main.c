#include <stdio.h>
#include <stdlib.h>
#include "route_records.h"

int main( int argc, char *argv[] )
{
    	int menuNum;
    	int x = 1;
    	char searchO[4] = "";
    	char searchD[4] = "";
    	char searchA[3] = "";
    
    	if(argc<2)//This determines if the user inputed a file/second argument 
    	{
        	printf("ERROR: Missing file name");
        	return -1;
    	}
    
    	printf("Opening %s...\n", argv[1]);
    	FILE* fileIn = NULL;
    	fileIn = fopen(argv[1], "r");//This opens the file and prepares it to be read
    
    	if(fileIn==NULL)//This determines if the file could be opened or not
    	{
        	printf("ERROR: Could not open file");
        	return -1;
    	}
    
    	RouteRecord* r = createRecords(fileIn);//This calls the CreateRecords funtion which fills an array with zeros
    
    	int totalRecordCount = fillRecords(r,fileIn);//This calls fillRecords which fills the previously made array with falues from the data file.
        printf("Unique routes operated by airlines: %d", totalRecordCount-1);
    	fclose(fileIn);//This closes the file

	    while(x)//This while loop will itterate infinitely until the user inputs "5"
	    {
        	printMenu();
	        scanf("%d", &menuNum);
        	switch(menuNum)//This switch statement uses a user Input and determines what to show them based on that input.
        	{
            	case 1://This is if they chose option 1, it will ask for 2 keys (Origin & Destination) that it will then send to searchRecords to be parsed with.
                	printf("Enter Origin: ");
                	scanf("%s", searchO);
                	printf("Enter Destination: ");
                	scanf("%s", searchD);
                	searchRecords(r, totalRecordCount, searchO, searchD, 0);
                	break;
            	case 2://This is if they choose option 2, it will ask for 1 key (Origin) that it will then send to searchRecords to be parsed with.
                	printf("Enter Origin: ");
                	scanf("%s", searchO);
                	searchRecords(r, totalRecordCount, searchO, searchD, 1);
                	break;
            	case 3://This is if they choose option 3, it will ask for 1 key (Destination) that it will then send to searchRecords to be parsed with.
                	printf("Enter Destination: ");
                	scanf("%s", searchD);
                	searchRecords(r, totalRecordCount, searchD, searchO, 2);
                	break;
            	case 4://This is if they choose option 4, it will ask for 1 key (Airline) that it will then send to searchRecords to be parsed with.
                	printf("Enter Airline: ");
                	scanf("%s", searchA);
                	searchRecords(r, totalRecordCount, searchA, searchO, 3);
                	break;
            	case 5://This is if they choose option 5, which sets x=0 and ends the while loop.
                	printf("Goodbye!\n");
                	x=0;
                	break;
            	default://This is if they enter something other than 1-5
            	printf("Invalid Choice.");
			break;
        	}
        
    	}
    
    
    
    	return 0;
}

