#ifndef ROUTE_RECORDS_H
#define ROUTE_RECORDS_H
#include<stdio.h>
typedef struct RouteRecord//This creates the struct that will hold the objects for each matcing flight
{
    int month;
    char origCode[4];
    char destCode[4];
    char airCode[4];
    int numPass[6];
} RouteRecord;

typedef enum SearchType { ROUTE, ORIGIN, DESTINATION, AIRLINE } SearchType;//This enum stores the values for user input and is later referenced
RouteRecord* createRecords(FILE* fileIn);
int fillRecords(RouteRecord* r, FILE* fileIn);
int findAirlineRoute(RouteRecord* r, int length, const char* origin, const char* destination, const char* airline, int curIdx);
void searchRecords(RouteRecord* r, int length, const char* key1, const char* key2, SearchType st);
void printMenu();

#endif
