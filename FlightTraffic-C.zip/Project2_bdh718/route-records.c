#include "route_records.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

RouteRecord* createRecords(FILE* fileIn)//This funtion finds how many lines are in the file, dynamically allocates space for an array of count size, and sets the struct passenger count array to zero for every struct object
{
    int count=0;
    int i;
    int j;
    char buffer[100];
    char topLine[100];
    
    fgets(topLine,100,fileIn);

    while(fgets(buffer,100,fileIn)!=NULL)//This counts the number of lines in the data file
    {
        count++;
    }

    RouteRecord *records = (RouteRecord*)malloc(count * sizeof(RouteRecord));//This dynamically allocates space for an array of count size

    for (i = 0; i < count; i++) //This fills the numPass array for each struct object with zero's
    {
        for (j = 0; j < 6; j++) 
        {
            records[i].numPass[j] = 0;
        }
    }
    rewind(fileIn);//This rewinds the file to the top
    return records;
}

int fillRecords( RouteRecord* r, FILE* fileIn )//This scans in every line of the file and compares each lines data to every other line in the file. If it finds a match, it adds 1 to a counter. It returns the number of matches.
{
    char buffer[100];
    int count = 0;
    char tempOrigin[4];
    char tempDest[4];
    char tempComp[2];
    int tempPass = 0;
    int tempMonth;
    int foundIndex = 0;
    
    while(fgets(buffer,100,fileIn)!=NULL)//This itterates a line amount number of time
    {
        sscanf(buffer,"%d,%[^,],%[^,],%[^,],%*[^,],%d", &tempMonth, tempOrigin, tempDest, tempComp, &tempPass);//This scans in each line and assigns all data to temporary values
        foundIndex = findAirlineRoute(r, count, tempOrigin, tempDest, tempComp, count);//This sends those temporary values to be checked. A -1 is returned if they match
        if(foundIndex==-1)//If a match is found in findAirlineRoute, the values that rendered the match are recorded
        {
            r[count].month = tempMonth;
            strcpy(r[count].origCode, tempOrigin);
            strcpy(r[count].destCode, tempDest);
            strcpy(r[count].airCode, tempComp);
            r[count].numPass[tempMonth-1] = tempPass;
            count++;
        }
        else
        {
            r[foundIndex].numPass[tempMonth-1] = tempPass;
        }
    }
    return count;    
}

int findAirlineRoute( RouteRecord* r, int length, const char* origin, const char* destination, const char* airline, int curIdx )//This recursively scans itself with the input until a match is or is not found
{
    if(curIdx==0)
    {
        return -1;
    }
    if(strcmp(r[curIdx].origCode, origin)==0 && strcmp(r[curIdx].destCode, destination)==0 && strcmp(r[curIdx].airCode, airline)==0)//This compares all inputs with each index of the file and returns that index if found
    {
            return curIdx;   
    }
    else//This is the recursive call
    {
        return findAirlineRoute(r, length, origin, destination, airline, --curIdx);
    }
    
}

void searchRecords(RouteRecord* r, int length, const char* key1, const char* key2, SearchType st)//This searches the records based on the input recieved from user, and printsthe records that match it 
{
    int match = 0;
    int totalPass = 0;
    int passPerMonth[6] = {0,0,0,0,0,0};
    int i;
    int j;
    int n;

    switch(st)//This utilizes the enum and prints flight info based on what the user inputed
    {
        case 0://This searches by route, and prints all data members that match the given route.
            printf("\nSearching by route...\n");
            for(i = 0;i<length;i++)
            {
                if(strcmp(r[i].origCode, key1)==0 && strcmp(r[i].destCode, key2)==0)
                {
                    printf("%s (%s-%s) ", r[i].airCode, r[i].origCode, r[i].destCode);
                    for(j = 0;j<6;j++)//This acts as a counter for total passengers and for passengers in a given month.
                    {
                        totalPass += r[i].numPass[j];
                        passPerMonth[j] += r[i].numPass[j];
                    }
                    match++;
                }
            }
            break;
        case 1://This searches by Origin, and prints all data members that match the given Origin.
	    printf("\nSearching by origin...\n");
            for(i = 0;i<length;i++)
            {
                if(strcmp(r[i].origCode, key1)==0)
                {
                    printf("%s (%s-%s) ", r[i].airCode, r[i].origCode, r[i].destCode);
                    for(j = 0;j<6;j++)//This acts as a counter for total passengers and for passengers in a given month.
                    {
                        totalPass += r[i].numPass[j];
                        passPerMonth[j] += r[i].numPass[j];
                    }
                    match++;
                }
            }
            break;
        case 2://This searches by destination, and prints all data members that match the given destination.
	    printf("\nSearching by destination...\n");
            for(i = 0;i<length;i++)
            {
                if(strcmp(r[i].destCode, key1)==0)
                {
                    printf("%s (%s-%s) ", r[i].airCode, r[i].origCode, r[i].destCode);
                    for(j = 0;j<6;j++)//This acts as a counter for total passengers and for passengers in a given month.
                    {
                        totalPass += r[i].numPass[j];
                        passPerMonth[j] += r[i].numPass[j];
                    }
                    match++;
                }
            }
            break;
        case 3://This searches by airline, and prints all data members that match the given airline.
	    printf("\nSearch by airline...\n");//example output says this, I figure "Searching by airline..." makes more sence though. 
            for(i = 0;i<length;i++)
            {
                if(strcmp(r[i].airCode, key1)==0)
                {
                    printf("%s (%s-%s) ", r[i].airCode, r[i].origCode, r[i].destCode);
                    for(j = 0;j<6;j++)//This acts as a counter for total passengers and for passengers in a given month.
                    {
                        totalPass += r[i].numPass[j];
                        passPerMonth[j] += r[i].numPass[j];
                    }
                    match++;
                }
            }
            break;
    }
    printf("\n%d matches were found.\n\nStatistics\n", match);//This series of statements prints all info calculated based off of user input
    printf("Total Passengers:              %d\n", totalPass);
    for(n = 0;n<6;n++)
    {
        printf("Total Passengers in Month %d:   %d\n", n+1, passPerMonth[n]);    
    }
    printf("\nAverage Passengers per Month:    %d", (totalPass/6));
}

void printMenu() 
{
    printf( "\n\n\n######### Airline Route Records Database MENU #########\n" );
    printf( "1. Search by Route\n" );     
    printf( "2. Search by Origin Airport\n" );
    printf( "3. Search by Destination Airport\n" );
    printf( "4. Search by Airline\n" );
    printf( "5. Quit\n" );
    printf( "Enter your selection: " );

}
